import { Injectable } from '@angular/core';
import  data from '../../assets/json/data.json';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  private CategoriasList: any[] = data.categorias;
  private ProductosList: any[] = data.productos;

  constructor() {}

  getCategorias(){
    return this.CategoriasList
  }

  getProductos(){
    return this.ProductosList
  }
}



