import { Component } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { CMTService } from '../CmTService/cmt.service';
import { Router } from '@angular/router';
import { CheckoutComponent } from '../checkout/checkout.component';
import { timer } from 'rxjs';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {
  categoria: any[] = [];
  ApiRoot: any;
  constructor(private CMTService: CMTService, private router: Router) { }


  redirectcategoria(categoriaid) {
    //console.log(categoriaid)

    this.router.navigate(['categorias/' + categoriaid]);
  }

  redirectquiensomos() {
    this.router.navigate(['quiensomos']);
  }

  checkout() {
    this.router.navigate(['checkout']);
  }

  redirecthome() {
    this.router.navigate(['home']);
  }

  redirectvendetutech() {
    this.router.navigate(['quiensomos']);
  }

  redirecthelp() {
    this.router.navigate(['ayuda']);
  }

  ngOnInit() {
    this.CMTService.getCategorias().then(
      (data) => {
        this.categoria = data;
        //console.log("categoria cargadas:", this.categoria);
      },
      (error) => {
        console.error('Error al obtener las categoria:', error);
      }
    );
  }



}

