import { CommonModule } from '@angular/common';
import { Component, OnInit, CUSTOM_ELEMENTS_SCHEMA, Input } from '@angular/core';
import { CarruselProductosService } from './carruselproductos.service';
import { Router } from '@angular/router';
import { ProductService } from '../products/products.service';

@Component({
  selector: 'app-carruselproductos',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './carruselproductos.component.html',
  styleUrls: ['./carruselproductos.component.css'],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CarruselproductosComponent implements OnInit {
  @Input() productos: any[] = [];
  productoChunks: any[][] = [];

  constructor(
    private carruselProductosService: CarruselProductosService,
    private router: Router,  
    private productService: ProductService
  ) {}

  onComprar(productIdBton: string) {
    this.productService.setProductId(productIdBton);    
    this.router.navigate(['products/'+productIdBton]);  
    //console.log("llega aqui la id?: ",this.productService.getProductId())
    //console.log("Detalles de la id?: ",this.productService.getProductoDetalles())
  }

  ngOnInit(): void {
    this.carruselProductosService.getProductos().then(
      (data) => {
        this.productos = data;
        this.chunkProductos();
        console.log("Productos cargados:", this.productos);
      },
      (error) => {
        console.error('Error al obtener los productos:', error);
      }
    );
  }
  chunkProductos(): void {
    const chunkSize = 4;
    for (let i = 0; i < this.productos.length; i += chunkSize) {
      this.productoChunks.push(this.productos.slice(i, i + chunkSize));
    }
  }
}
