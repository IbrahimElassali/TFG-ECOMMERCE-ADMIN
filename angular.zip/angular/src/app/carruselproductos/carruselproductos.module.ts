import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{CarruselproductosComponent} from './carruselproductos.component';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CarruselproductosComponent
  ]
})
export class CarruselproductosModule { }
