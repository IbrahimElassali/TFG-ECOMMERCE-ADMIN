import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CarruselComponent } from '../carrusel/carrusel.component';
import { CarruselproductosComponent } from '../carruselproductos/carruselproductos.component';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    FooterComponent,
    CarruselproductosComponent,
    CarruselComponent,
  ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  constructor(private router: Router,private cookieService: CookieService) {
    this.cookieService.set('myCookie', 'cookieValue', 7);
  }
  
  ngOnInit() {
    this.setAnonymousIdCookie();
  }

  private setAnonymousIdCookie() {
    let anonymousId = this.cookieService.get('anonymousId');

    if (!anonymousId) {
      anonymousId = this.generateUUID();
      this.cookieService.set('anonymousId', anonymousId, 7);
    }

    //console.log('Anonymous ID:', anonymousId); 
  }

  private generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
  

}
