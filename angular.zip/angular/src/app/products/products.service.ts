import { Injectable } from '@angular/core';
import {
  AuthMiddlewareOptions,
  ClientBuilder,
  HttpMiddlewareOptions,
} from '@commercetools/sdk-client-v2';

import {
  createApiBuilderFromCtpClient,
} from '@commercetools/platform-sdk';

import { CheckoutService } from '../checkout/checkout.service'; // Importar el CheckoutService

interface ProductoDetalle {
  productId: string;
  productName: string;
  productDescription: string;
  productImages: string[];
  productPrice: number | null;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private productId: string | null = null;
  private cartId: string | null = null;
  private ApiRoot: any;

  constructor(private checkoutService: CheckoutService) { // Inyectar el CheckoutService
    this.initApiRoot();
  }

  private initApiRoot(): void {
    const CTP_PROJECT_KEY = 'bk-project';
    const CTP_CLIENT_SECRET = 'yvDduav2ir28iVmHp3uCe-ViZ5VQg8kh';
    const CTP_CLIENT_ID = 'dUEXztgAdhI0bVxCQ-RPzpvw';
    const CTP_AUTH_URL = 'https://auth.eu-central-1.aws.commercetools.com';
    const CTP_API_URL = 'https://api.eu-central-1.aws.commercetools.com';
    const CTP_SCOPES =
      'manage_types:bk-project manage_categories:bk-project manage_my_shopping_lists:bk-project manage_shopping_lists:bk-project manage_my_orders:bk-project manage_customers:bk-project manage_discount_codes:bk-project create_anonymous_token:bk-project manage_my_profile:bk-project manage_cart_discounts:bk-project manage_shipping_methods:bk-project manage_products:bk-project manage_payments:bk-project manage_project_settings:bk-project manage_customer_groups:bk-project manage_orders:bk-project manage_order_edits:bk-project manage_my_payments:bk-project manage_extensions:bk-project manage_tax_categories:bk-project';

    const authMiddlewareOptions: AuthMiddlewareOptions = {
      host: CTP_AUTH_URL,
      projectKey: CTP_PROJECT_KEY,
      credentials: {
        clientId: CTP_CLIENT_ID,
        clientSecret: CTP_CLIENT_SECRET,
      },
      scopes: [CTP_SCOPES],
    };

    const httpMiddlewareOptions: HttpMiddlewareOptions = {
      host: CTP_API_URL,
    };

    const client = new ClientBuilder()
      .withProjectKey(CTP_PROJECT_KEY)
      .withClientCredentialsFlow(authMiddlewareOptions)
      .withHttpMiddleware(httpMiddlewareOptions)
      .withLoggerMiddleware()
      .build();

    this.ApiRoot = createApiBuilderFromCtpClient(client);
  }

  setProductId(productId: string): void {
    this.productId = productId;
  }

  getProductId(): string | null {
    return this.productId;
  }

  setCartId(cartId: string): void {
    this.cartId = cartId;
  }

  getCartId(): string | null {
    return this.cartId;
  }

  async getProductoDetalles(productId: string): Promise<ProductoDetalle[]> {
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey: 'bk-project' })
        .products()
        .withId({ ID: productId })
        .get()
        .execute();

      const product = response.body;

      if (product) {
        const productPrice = product.masterData.current.masterVariant.prices.length > 0 
          ? product.masterData.current.masterVariant.prices[0].value.centAmount / 100 
          : null;

        return [{
          productId: product.id,
          productName: product.masterData.current.name['en-US'],
          productDescription: product.masterData.current.masterVariant.attributes
            .filter((attribute: any) => attribute.name === 'description-attribute')
            .map((attribute: any) => attribute.value['en-US'])
            .join(', '),
          productImages: product.masterData.current.masterVariant.images.map((image: any) => image.url),
          productPrice,
        }];
      } else {
        throw new Error('Producto no encontrado.');
      }
    } catch (error) {
      console.error('Error al obtener detalles del producto:', error);
      throw error;
    }
  }

  async addToCart(): Promise<void> {
    if (!this.productId) {
      console.error('No se ha establecido el ID del producto.');
      return;
    }

    try {
      const { cartId, version } = await this.checkoutService.manageCart(this.productId);
      this.setCartId(cartId); // Actualizar el cartId en el servicio
    } catch (error) {
      console.error('Error adding product to cart:', error);
    }
  }
}
