import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { ProductService } from './products.service';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  productId: string | null = null;
  detallesProduct: any[] = [];
  selectedProductId: string | null = null;

  constructor(private productService: ProductService,
     private route: ActivatedRoute,
     private router: Router, 
     ) {}
  onCheckOut(){
    this.router.navigate(['checkout']); 
  }
  onAddToCart(productId: string): void {
    this.selectedProductId = productId;
    this.productService.setProductId(productId);
    this.productService.addToCart().then(() => {
      console.log('Producto añadido al carrito');
    }).catch((error) => {
      console.error('Error al añadir producto al carrito:', error);
    });
  }
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.productId = params.get('id');
      if (this.productId) {
        this.productService.setProductId(this.productId);
        this.productService.getProductoDetalles(this.productId).then(details => {
          this.detallesProduct = details;
          console.log('Esto son los detalles del producto:', this.detallesProduct);
        }).catch(error => {
          console.error('Error fetching product details:', error);
        });
      }
    });
  }
}
