import { Injectable } from '@angular/core';
import data from '../../assets/json/data.json';

@Injectable({
  providedIn: 'root'
})
export class CarruselService {

  private CarruselList: any[] = data.carrusel;

  constructor() { }

  getCarrusel(){
    return this.CarruselList
  }
}
