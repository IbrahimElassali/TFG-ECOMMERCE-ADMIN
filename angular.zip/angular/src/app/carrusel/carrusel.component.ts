import { Component,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CarruselService } from './carrusel.service';
import { CommonModule } from '@angular/common';
import { NgOptimizedImage } from '@angular/common';
@Component({
  selector: 'app-carrusel',
  standalone: true,
  imports: [CommonModule,NgOptimizedImage],
  templateUrl: './carrusel.component.html',
  styleUrl: './carrusel.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CarruselComponent {
  carrusel: any[] = [];

  constructor(private CarruselService: CarruselService) {}

  ngOnInit() {
    this.carrusel = this.CarruselService.getCarrusel();
    /*console.log('Carrusel cargado:', this.carrusel);*/
  }

}
