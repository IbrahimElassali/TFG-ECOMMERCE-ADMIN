import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-ayuda',
  standalone: true,
  imports: [HeaderComponent, FooterComponent],
  templateUrl: './ayuda.component.html',
  styleUrl: './ayuda.component.css'
})
export class AyudaComponent {
  constructor( private router: Router) { }
  redirecthome(){
    this.router.navigate(['home']);
  }
}
