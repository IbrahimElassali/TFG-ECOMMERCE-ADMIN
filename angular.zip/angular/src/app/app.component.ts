import { Component, VERSION , CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { HomeComponent } from './home/home.component';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  constructor(private cookieService: CookieService){
    this.setAnonymousIdCookie();
  }
  private setAnonymousIdCookie() {
    let anonymousId = this.cookieService.get('anonymousId');

    if (!anonymousId) {
      anonymousId = this.generateUUID();
      this.cookieService.set('anonymousId', anonymousId, 7); 
    }

    //console.log('Anonymous ID:', anonymousId);
  }

  private generateUUID(): string {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}
