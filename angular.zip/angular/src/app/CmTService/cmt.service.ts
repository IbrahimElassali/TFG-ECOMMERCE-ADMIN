import { Injectable } from '@angular/core';
import { ApiRoot } from '@commercetools/platform-sdk';


import {
  AuthMiddlewareOptions,
  ClientBuilder,
  HttpMiddlewareOptions,
} from '@commercetools/sdk-client-v2';
import {
  ClientResponse,
  createApiBuilderFromCtpClient,
  Product,
  Category,
  ProductPagedQueryResponse,
  CategoryPagedQueryResponse
} from '@commercetools/platform-sdk';


@Injectable({ providedIn: 'root' })
export class CMTService {
  ApiRoot: any;
  private Categoria: any[] = [];
  constructor() {
    this.initApiRoot();
  }
  private async initApiRoot(): Promise<void> {
    const CTP_PROJECT_KEY = 'bk-project';
    const CTP_CLIENT_SECRET = 'yvDduav2ir28iVmHp3uCe-ViZ5VQg8kh';
    const CTP_CLIENT_ID = 'dUEXztgAdhI0bVxCQ-RPzpvw';
    const CTP_AUTH_URL = 'https://auth.eu-central-1.aws.commercetools.com';
    const CTP_API_URL = 'https://api.eu-central-1.aws.commercetools.com';
    const CTP_SCOPES =
      'manage_types:bk-project manage_categories:bk-project manage_my_shopping_lists:bk-project manage_shopping_lists:bk-project manage_my_orders:bk-project manage_customers:bk-project manage_discount_codes:bk-project create_anonymous_token:bk-project manage_my_profile:bk-project manage_cart_discounts:bk-project manage_shipping_methods:bk-project manage_products:bk-project manage_payments:bk-project manage_project_settings:bk-project manage_customer_groups:bk-project manage_orders:bk-project manage_order_edits:bk-project manage_my_payments:bk-project manage_extensions:bk-project manage_tax_categories:bk-project';

    const credentials = {
      clientId: CTP_CLIENT_ID,
      clientSecret: CTP_CLIENT_SECRET,
    };
    const projectKey = CTP_PROJECT_KEY;

    const authMiddlewareOptions: AuthMiddlewareOptions = {
      host: CTP_AUTH_URL,
      projectKey,
      credentials: {
        clientId: CTP_CLIENT_ID,
        clientSecret: CTP_CLIENT_SECRET,
      },
      scopes: [CTP_SCOPES],
    };

    const httpMiddlewareOptions: HttpMiddlewareOptions = {
      host: CTP_API_URL,
    };

    const client = new ClientBuilder()
      .withProjectKey(projectKey)
      .withClientCredentialsFlow(authMiddlewareOptions)
      .withHttpMiddleware(httpMiddlewareOptions)
      .withLoggerMiddleware()
      .build();


    this.ApiRoot = createApiBuilderFromCtpClient(client);

    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .categories()
        .get()
        .execute();
      const body = response.body;

      if (body && body.results) {
        this.Categoria = body.results.map((category: any) => ({
          CategoryId: category.id,
          CategoryName: category.name['en-US'],
        }));

      } else {
        console.error('No category found or invalid response format');
      }
    } catch (error) {
      console.error('Error fetching category:', error);
    }
  }

  async getCategorias(): Promise<any[]> {
    await this.initApiRoot();
    return this.Categoria;
  }


}