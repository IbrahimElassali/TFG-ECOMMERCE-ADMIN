import { HomeComponent } from './home/home.component';
import { Routes } from '@angular/router';
import { ProductsComponent } from './products/products.component';

export const AppRoute: Routes = [
  {
    path: '',
    component: HomeComponent,
  },
  {
    path: 'products',
    component: ProductsComponent,
  }
];
