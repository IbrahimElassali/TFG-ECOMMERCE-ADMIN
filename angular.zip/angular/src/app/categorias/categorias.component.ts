import { Component, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { ActivatedRoute, Router } from '@angular/router';
import { CategoryProductQueryService } from './categorias.service';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-categorias',
  standalone: true,
  imports: [HeaderComponent, FooterComponent,CommonModule],
  templateUrl: './categorias.component.html',
  styleUrls: ['./categorias.component.css']
})
export class CategoriasComponent implements OnInit {
  categoriaid: string | null = null;
  productos: any[] = [];

  constructor(
    private categoryProductQueryService: CategoryProductQueryService,
    private route: ActivatedRoute,
    private router: Router,
  ) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(async params => {
      this.categoriaid = params.get('id');
      if (this.categoriaid) {
        this.categoryProductQueryService.setCategoryId(this.categoriaid);
        await this.loadProductos();
        console.log("Component", this.productos); 
      }
    });
  }

  async loadProductos(): Promise<void> {
    try {
      const queryProducts = await this.categoryProductQueryService.getProductosCategory();      
      console.log("que devuelve categoryproducs", queryProducts);      
      this.productos = queryProducts; 
     
    } catch (error) {
      console.error('Error fetching productos:', error);
    }
  }
  
}
