import { Injectable } from '@angular/core';
import { AuthMiddlewareOptions, ClientBuilder, HttpMiddlewareOptions } from '@commercetools/sdk-client-v2';
import { createApiBuilderFromCtpClient } from '@commercetools/platform-sdk';

@Injectable({
  providedIn: 'root'
})
export class CategoryProductQueryService {
  private apiRoot: any;
  private productosCategory: any[] = [];
  private idCategoria: string | null = null;

  constructor() {
    this.initApiRoot();
  }

  private initApiRoot(): void {
    const CTP_PROJECT_KEY = 'bk-project';
    const CTP_CLIENT_SECRET = 'yvDduav2ir28iVmHp3uCe-ViZ5VQg8kh';
    const CTP_CLIENT_ID = 'dUEXztgAdhI0bVxCQ-RPzpvw';
    const CTP_AUTH_URL = 'https://auth.eu-central-1.aws.commercetools.com';
    const CTP_API_URL = 'https://api.eu-central-1.aws.commercetools.com';
    const CTP_SCOPES = 'manage_types:bk-project manage_categories:bk-project manage_my_shopping_lists:bk-project manage_shopping_lists:bk-project manage_my_orders:bk-project manage_customers:bk-project manage_discount_codes:bk-project create_anonymous_token:bk-project manage_my_profile:bk-project manage_cart_discounts:bk-project manage_shipping_methods:bk-project manage_products:bk-project manage_payments:bk-project manage_project_settings:bk-project manage_customer_groups:bk-project manage_orders:bk-project manage_order_edits:bk-project manage_my_payments:bk-project manage_extensions:bk-project manage_tax_categories:bk-project';

    const authMiddlewareOptions: AuthMiddlewareOptions = {
      host: CTP_AUTH_URL,
      projectKey: CTP_PROJECT_KEY,
      credentials: {
        clientId: CTP_CLIENT_ID,
        clientSecret: CTP_CLIENT_SECRET,
      },
      scopes: [CTP_SCOPES],
    };

    const httpMiddlewareOptions: HttpMiddlewareOptions = {
      host: CTP_API_URL,
    };

    const client = new ClientBuilder()
      .withProjectKey(CTP_PROJECT_KEY)
      .withClientCredentialsFlow(authMiddlewareOptions)
      .withHttpMiddleware(httpMiddlewareOptions)
      .withLoggerMiddleware()
      .build();

    this.apiRoot = createApiBuilderFromCtpClient(client);
  }

  setCategoryId(categoriaId: string): void {
    this.idCategoria = categoriaId;
    console.log('Categoria ID:', this.idCategoria);
  }

  async fetchProductosByCategoria(): Promise<void> {
    if (!this.idCategoria) {
      console.error('Category ID is not set.');
      return;
    }

    const projectKey = 'bk-project';

    try {
      const response = await this.apiRoot
        .withProjectKey({ projectKey })
        .productProjections()
        .get({
          queryArgs: {
            where: `categories(id="${this.idCategoria}")`,
          },
        })
        .execute();

      const body = response.body;
      if (body && body.results) {
        this.productosCategory = body.results.map((product: any) => {
          const masterVariant = product.masterVariant;
          const attributes = masterVariant.attributes.reduce((acc: any, attr: any) => {
            acc[attr.name] = attr.value;
            return acc;
          }, {});

          return {
            productName: attributes['name'] ? attributes['name']['en-US'] : '',
            productDescription: product.description ? product.description['en-US'] : '',
            productImages: masterVariant.images.map((image: any) => image.url),
            productPrice: masterVariant.prices[0]?.value.centAmount / 100 || 0,
          };
        });
      } else {
        console.error('No products found or invalid response format');
      }
    } catch (error) {
      console.error('Error fetching products by category:', error);
    }
  }

  async getProductosCategory(): Promise<any[]> {
    await this.fetchProductosByCategoria();
    return this.productosCategory;
  }
}
