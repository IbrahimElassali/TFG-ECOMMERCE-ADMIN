import { Injectable } from '@angular/core';
import { ApiRoot } from '@commercetools/platform-sdk';
import {
  AuthMiddlewareOptions,
  ClientBuilder,
  HttpMiddlewareOptions,
} from '@commercetools/sdk-client-v2';
import { createApiBuilderFromCtpClient } from '@commercetools/platform-sdk';
import { CookieService } from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root',
})
export class CheckoutService {
  private ApiRoot: any;

  constructor(private cookieService: CookieService) {
    this.initApiRoot();
  }

  private initApiRoot(): void {
    const CTP_PROJECT_KEY = 'bk-project';
    const CTP_CLIENT_SECRET = 'yvDduav2ir28iVmHp3uCe-ViZ5VQg8kh';
    const CTP_CLIENT_ID = 'dUEXztgAdhI0bVxCQ-RPzpvw';
    const CTP_AUTH_URL = 'https://auth.eu-central-1.aws.commercetools.com';
    const CTP_API_URL = 'https://api.eu-central-1.aws.commercetools.com';
    const CTP_SCOPES = 'manage_types:bk-project manage_categories:bk-project manage_my_shopping_lists:bk-project manage_shopping_lists:bk-project manage_my_orders:bk-project manage_customers:bk-project manage_discount_codes:bk-project create_anonymous_token:bk-project manage_my_profile:bk-project manage_cart_discounts:bk-project manage_shipping_methods:bk-project manage_products:bk-project manage_payments:bk-project manage_project_settings:bk-project manage_customer_groups:bk-project manage_orders:bk-project manage_order_edits:bk-project manage_my_payments:bk-project manage_extensions:bk-project manage_tax_categories:bk-project';

    const credentials = {
      clientId: CTP_CLIENT_ID,
      clientSecret: CTP_CLIENT_SECRET,
    };
    const projectKey = CTP_PROJECT_KEY;

    const authMiddlewareOptions: AuthMiddlewareOptions = {
      host: CTP_AUTH_URL,
      projectKey,
      credentials,
      scopes: [CTP_SCOPES],
    };

    const httpMiddlewareOptions: HttpMiddlewareOptions = {
      host: CTP_API_URL,
    };

    const client = new ClientBuilder()
      .withProjectKey(projectKey)
      .withClientCredentialsFlow(authMiddlewareOptions)
      .withHttpMiddleware(httpMiddlewareOptions)
      .withLoggerMiddleware()
      .build();

    this.ApiRoot = createApiBuilderFromCtpClient(client);
  }

  public async getCarrito(): Promise<any> {
    const anonymousId = this.cookieService.get('anonymousId');
    const projectKey = 'bk-project';
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .get({
          queryArgs: {
            where: `anonymousId="${anonymousId}"`
          }
        })
        .execute();
      return response.body.results[0];
    } catch (error) {
      console.error('Error fetching cart:', error);
      return null;
    }
  }

  public async generarOrden(cartId: string): Promise<any> {
    const projectKey = 'bk-project';
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .withId({ ID: cartId })
        .get()
        .execute();

      const cart = response.body;
      const cartVersion = cart.version;

      const orderResponse = await this.ApiRoot
        .withProjectKey({ projectKey })
        .orders()
        .post({
          body: {
            version: cartVersion,
            cart: {
              id: cartId,
              typeId: 'cart',
            },
          },
        })
        .execute();

      console.log('Orden creada correctamente:', orderResponse.body);
      return orderResponse.body;
    } catch (error) {
      console.error('Error al crear la orden:', error);
      throw error;
    }
  }

  public async borrarProductoDelCarrito(productId: string): Promise<any> {
    const anonymousId = this.cookieService.get('anonymousId');
    const projectKey = 'bk-project';
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .get({
          queryArgs: {
            where: `anonymousId="${anonymousId}"`,
          },
        })
        .execute();

      const cart = response.body.results[0];
      const cartId = cart.id;
      const cartVersion = cart.version;

      await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .withId({ ID: cartId })
        .post({
          body: {
            version: cartVersion,
            actions: [
              {
                action: 'removeLineItem',
                lineItemId: productId,
              },
            ],
          },
        })
        .execute();

      console.log('Producto eliminado del carrito correctamente.');   

      return true;
    } catch (error) {
      console.error('Error al eliminar producto del carrito o generar la orden:', error);
      return false
    }
  }

  private async createCarrito(): Promise<any> {
    const anonymousId = this.cookieService.get('anonymousId');
    const projectKey = 'bk-project';
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .post({
          body: {
            anonymousId: anonymousId,
            currency: 'USD'
          }
        })
        .execute();
      return response.body;
    } catch (error) {
      console.error('Error creating cart:', error);
      throw error;
    }
  }

  private async addProductoAlCarrito(cartId: string, version: number, productId: string): Promise<any> {
    const projectKey = 'bk-project';
    try {
      const response = await this.ApiRoot
        .withProjectKey({ projectKey })
        .carts()
        .withId({ ID: cartId })
        .post({
          body: {
            version: version,
            actions: [{
              action: 'addLineItem',
              productId: productId,
              quantity: 1
            }]
          }
        })
        .execute();
      return response.body;
    } catch (error) {
      console.error('Error adding product to cart:', error);
      throw error;
    }
  }

  public async manageCart(productId: string): Promise<{ cartId: string, version: number }> {
    let cart = await this.getCarrito();
    if (!cart) {
      cart = await this.createCarrito();
    }
    await this.addProductoAlCarrito(cart.id, cart.version, productId);
    return { cartId: cart.id, version: cart.version };
  }
}
