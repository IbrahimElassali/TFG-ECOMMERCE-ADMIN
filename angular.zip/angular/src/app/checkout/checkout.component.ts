import { Component, Input, OnInit } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { CookieService } from 'ngx-cookie-service';
import { CheckoutService } from './checkout.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { ProvinciasService } from '../apiProvincias/provincias.service';

@Component({
  selector: 'app-checkout',
  standalone: true,
  imports: [HeaderComponent, FooterComponent,CommonModule],
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  @Input() carrito: any = {};
  itemsCarrito: any[] = [];
  provincias: string[] = [];
  idCarrito: string | null = null;
  constructor(
    private cookieService: CookieService,
    private route: ActivatedRoute,
    private router: Router,
    private checkoutService: CheckoutService,
    private provinciasService: ProvinciasService
  ) { }

  ngOnInit(): void {
    this.provinciasService.getProvincias().subscribe(provincias => {
      this.provincias = provincias;
    });
        
    this.fetchCarrito();
    
  }

  async fetchCarrito(): Promise<void> {
    try {
      const carro = await this.checkoutService.getCarrito();
      if (carro && carro.lineItems && Array.isArray(carro.lineItems)) {
        this.carrito = carro;
        this.idCarrito = carro.id;
        console.log('Esto son los detalles del carrito:', this.carrito);
  
        this.itemsCarrito = carro.lineItems.map(item => ({
          id: item.id,
          name: item.name?.['en-US'] || 'No name',
          quantity: item.quantity,
          totalPrice: item.totalPrice?.centAmount ? item.totalPrice.centAmount / 100 : 0,
          description: item.variant?.attributes?.find(attr => attr.name === 'description-attribute')?.value?.['en-US'] || 'No description'
        }));
      } else {
        console.error('El carrito no tiene lineItems o no es un array:', carro);
      }
    } catch (error) {
      console.error('Error fetching cart:', error);
    }
  }
  
  deleteproduct(ItemId: string) {
    this.checkoutService.borrarProductoDelCarrito(ItemId).then(success => {
      console.log('success:', success);
      if (success) {
        Swal.fire({
          icon: "success",
          title: "Producto eliminado del carrito exitosamente",
          showConfirmButton: false,
          timer: 2000
        });
        
        this.fetchCarrito();
      } else {
        Swal.fire({
          icon: "error",
          title: "Error al eliminar el producto del carrito",
          showConfirmButton: false,
          timer: 2000
        });
      }
    });
    
  }
  

  async onPagar(idCarrito) {
    try {
      await this.checkoutService.generarOrden(idCarrito);
      Swal.fire({
        icon: 'success',
        title: 'Pago realizado exitosamente',
        showConfirmButton: false,
        timer: 8500
      }).then(() => {
        this.router.navigate(['home']);
      });
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Error al procesar el pago',
        text: 'Hubo un problema al eliminar el producto o generar la orden.',
        showConfirmButton: true
      });
    }
  }

}
