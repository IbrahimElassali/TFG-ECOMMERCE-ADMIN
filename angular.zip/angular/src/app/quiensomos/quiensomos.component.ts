import { Component } from '@angular/core';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component'; 
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
@Component({
  selector: 'app-quiensomos',
  standalone: true,
  imports: [CommonModule, HeaderComponent, FooterComponent],
  templateUrl: './quiensomos.component.html',
  styleUrl: './quiensomos.component.css'
})
export class QuiensomosComponent {
  constructor( private router: Router) { }
  redirecthelp() {   
    this.router.navigate(['ayuda']);  
  }
}
