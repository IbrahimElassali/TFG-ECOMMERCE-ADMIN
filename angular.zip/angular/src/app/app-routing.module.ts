import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { QuiensomosComponent } from './quiensomos/quiensomos.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { CategoriasComponent } from './categorias/categorias.component';
import { AyudaComponent } from './ayuda/ayuda.component';
const routes: Routes = [
  { path: '', redirectTo: 'home' },
  { path: 'home', component: HomeComponent },
  { path: 'categorias/:id', component: CategoriasComponent },
  { path: 'quiensomos', component: QuiensomosComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'ayuda', component: AyudaComponent },
  { path: 'products/:id', component: ProductsComponent },
  { path: '**', redirectTo: 'home' },
  
];
@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }