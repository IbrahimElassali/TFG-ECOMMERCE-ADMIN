// provincias.service.ts
import { Injectable } from '@angular/core';
import provinciasData from '../../assets/json/provincias.json';
import { of, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProvinciasService {
  constructor() { }

  getProvincias(): Observable<string[]> {
    const provincias = provinciasData.map(provincia => provincia.label);
    return of(provincias);
  }
}
